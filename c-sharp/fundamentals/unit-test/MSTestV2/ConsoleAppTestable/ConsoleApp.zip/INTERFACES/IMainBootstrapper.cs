﻿namespace $safeprojectname$.Interfaces
{
    public interface IMainBootstrapper
    {
        void Run(string[] args);
    }
}